import React from "react"

const Content = () => {

    const handleAdvName = () => {
        const advName = ["Earn","Grow","Give"];
        let indexOfName = Math.floor(Math.random()*3);
        return advName[indexOfName];
    }

    const handleForget = () => {
        console.log("Function excuted without invoked");
    }

    const handleLogin = (e) => {
        console.log(e);
        console.log(e.target);
    }

    return (
        <section className="p-5">
            <p className="py-5 text-xl">Let's {handleAdvName()} Money </p>
            <button className="bg-red-900 text-white py-2 px-4 text-lg rounded mr-10" onClick={handleForget()}>Forgot?</button>
            <button className="bg-green-900 text-white py-2 px-4 text-lg rounded" onClick={(e) => handleLogin(e)}>Login</button>
        </section>
    )
}

export default Content