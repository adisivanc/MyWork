import React from "react"
import { useState } from "react";

const Content = () => {

    const handleAdvName = () => {
        const advName = ["Earn","Grow","Give"];
        let indexOfName = Math.floor(Math.random()*3);
        setDynVal(advName[indexOfName]);
    }

    const [count,setState] = useState(99);
    const [dynVal,setDynVal] = useState("Earn");

    const handleIncrement = () => {
        return setState((prevCount) => prevCount + 1);
    }

    const handleDecrement = () => {
        return setState((prevCount) => prevCount - 1);
    }

    return (
        <section className="p-5 w-full">
            <p className="py-5 text-xl">Let's {dynVal} Money </p>
            <div className="flex w-full md:w-2/12 lg:w-2/12 justify-between">
                <button className="bg-green-900 text-white py-2 leading-none px-4 text-3xl rounded" onClick={()=>handleDecrement()}>-</button>
                <span className="inline-block align-middle text-2xl">{count}</span>
                <button className="bg-green-900 text-white py-2 leading-none px-4 text-3xl rounded" onClick={()=>handleIncrement()}>+</button>
            </div>
            <button className="bg-green-900 text-white py-2 px-4 text-lg rounded my-10" onClick={(e) => handleAdvName(e)}>Login</button>
        </section>
    )
}

export default Content