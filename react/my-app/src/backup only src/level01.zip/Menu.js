import React from "react"

const Menu = () => {

    return (
        <nav className="bg-pink-900 h-[calc(100vh-100px)] w-[180px]">
            Adversitment 
        </nav>
    )
}

export default Menu