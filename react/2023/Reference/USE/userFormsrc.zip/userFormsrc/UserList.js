import React, { useState } from "react";

const UserList = ({ listOfUserObj, setListOfUserObj }) => {
  const [userSelectAll, setUserSelectAll] = useState(false);

  const handleDelete = (e) => {
    const deletedList = listOfUserObj.filter((item) => {
      return item.checked === false;
    });
    setListOfUserObj(deletedList);
  };

  const handleCheck = (para) => {
    const updatedList = listOfUserObj.map((item) => {
      return item.id === para ? { ...item, checked: !item.checked } : item;
    });
    setListOfUserObj(updatedList);
  };

  const handleSelectAll = () => {
    const updatedList = listOfUserObj.map((item) => {
      return userSelectAll === false? { ...item, checked: true }:{ ...item, checked: false };
    });
    setListOfUserObj(updatedList);
    setUserSelectAll(!userSelectAll);
  };

  return (
    <div className="p-10">
      <div className="flex">
        <h4 className="text-xl uppercase font-semibold mb-5">User List</h4>
        <span onClick={(e) => handleDelete(e)} className="ml-auto">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none"
            viewBox="0 0 24 24"
            strokeWidth="1.5"
            stroke="currentColor"
            className="w-6 h-6"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"
            />
          </svg>
        </span>
      </div>
      <ul>
        <li className="flex border-b border-gray-700 py-2">
          <span className="w-12">
            <input
              type="checkbox"
              className="w-5 h-5 mr-2"
              checked={userSelectAll}
              onChange={() => handleSelectAll()}
            />
          </span>
          <span className="w-14">ID</span>
          <span className="w-[calc(20%-20.8px)]">First Name</span>
          <span className="w-[calc(20%-20.8px)]">Last Name</span>
          <span className="w-[calc(20%-20.8px)]">Email</span>
          <span className="w-[calc(20%-20.8px)]">Mobile Number</span>
          <span className="w-[calc(20%-20.8px)]">Password</span>
        </li>
        {listOfUserObj.length !== 0 ? (
          listOfUserObj.map((item) => {
            return (
              <li key={item.id} className="flex py-1">
                <span className="w-12">
                  <input type="checkbox"
                    className="w-5 h-5 mr-2"
                    checked={item.checked}
                    onChange={() => handleCheck(item.id)}
                  />
                </span>
                <span className="w-14">{item.id}</span>
                <span className="w-[calc(20%-20.8px)]">{item.firstName}</span>
                <span className="w-[calc(20%-20.8px)]">{item.lastName}</span>
                <span className="w-[calc(20%-20.8px)]">{item.email}</span>
                <span className="w-[calc(20%-20.8px)]">{item.mobileNumber}</span>
                <span className="w-[calc(20%-20.8px)]">{item.password}</span>
              </li>
            );
          })
        ) : (
          <p className="p-24 bg-gray-200 text-center">Empty</p>
        )}
      </ul>
    </div>
  );
};

export default UserList;
