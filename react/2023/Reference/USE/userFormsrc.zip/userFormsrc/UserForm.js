import React, { useState } from "react";

const UserForm = ({listOfUserObj,setListOfUserObj}) => {

    const [userFirstName,setUserFirstName] = useState("");
    const [userLastName,setUserLastName] = useState("");
    const [userEmail,setUserEmail] = useState("");
    const [userMobileNumber,setUserMobileNumber] = useState("");
    const [userPassword,setUserPassword] = useState("");
    const [userConfirmPassword,setUserConfirmPassword] = useState("");
    const [showPassword,setShowPassword] = useState(false);
    const [userId,setUserId] = useState(0);

    const handleShowPassword = () => {
        setShowPassword(!showPassword)
        console.log(showPassword);
    }

    const handleUserSubmit = (e) => {
        e.preventDefault();
        console.log("Form Submitted");
        const newUserObj = {
            id:userId+1,
            firstName:userFirstName,
            lastName:userLastName,
            email:userEmail,
            mobileNumber:userMobileNumber,
            password:userPassword,
            checked:false
        }
        
        const newListOfUserObj = [...listOfUserObj,newUserObj];
        setUserId(userId+1);
        handleReset();
        return setListOfUserObj(newListOfUserObj);
    }    

    const handleReset = () => {
        setUserFirstName("");
        setUserLastName("");
        setUserEmail("");
        setUserMobileNumber("");
        setUserPassword("");
        setUserConfirmPassword("");
    }

    return (
        <div className="p-10">
            <form className="max-w-sm" onSubmit={(e) => handleUserSubmit(e)}>
                <h4 className="text-xl uppercase font-semibold mb-5">User Registration</h4>
                <div>
                    <input type="text" className="focus:outline-none px-4 py-2 border border-orange-600 rounded w-full mb-2" placeholder="First Name" value={userFirstName} onChange={(e)=>setUserFirstName(e.target.value)} required/>
                </div>
                <div>
                    <input type="text" className="focus:outline-none px-4 py-2 border border-orange-600 rounded w-full mb-2" placeholder="Last Name" value={userLastName} onChange={(e)=>setUserLastName(e.target.value)} required/>
                </div>
                <div>
                    <input type="email" className="focus:outline-none px-4 py-2 border border-orange-600 rounded w-full mb-2" placeholder="Email ID" value={userEmail} onChange={(e)=>setUserEmail(e.target.value)} required/>
                </div>
                <div>
                    <input type="tel" className="focus:outline-none px-4 py-2 border border-orange-600 rounded w-full mb-2" placeholder="Mobile Number" value={userMobileNumber} onChange={(e)=>setUserMobileNumber(e.target.value)} required/>
                </div>
                <div>
                    <input type="password" className="focus:outline-none px-4 py-2 border border-orange-600 rounded w-full mb-2" placeholder="Set Password" value={userPassword} onChange={(e)=>setUserPassword(e.target.value)} required/>
                </div>
                <div>
                    <input type="password" className="focus:outline-none px-4 py-2 border border-orange-600 rounded w-full mb-2" placeholder="Confirm Password" value={userConfirmPassword} onChange={(e)=>setUserConfirmPassword(e.target.value)} required/>
                </div>
                <div className="my-2 flex">
                    <input type="checkbox" className="w-5 h-5 mr-2" onChange={()=>handleShowPassword()} /> 
                    <span className="">Show Password</span>
                </div>
                <div className="text-right">
                    <button type="button" className="px-4 py-2 bg-slate-900 text-white rounded-sm" onClick={()=>handleReset()}>Reset</button>
                    <button type="submit" className="px-4 py-2 bg-orange-900 text-white rounded-sm ml-7">Submit</button>
                </div>
            </form>
        </div>
    )
}

export default UserForm;