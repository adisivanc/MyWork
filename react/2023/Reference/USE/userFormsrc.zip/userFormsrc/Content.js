import React, { useState, useEffect } from "react";
import UserDetails from "./UserDetails";
import Advertisement from "./Advertisement";

const Content = () => {
    const [adTitle, setAdTitle] = useState("");
    const [adContent, setAdContent] = useState("");
    const [adImgSrc, setAdImgSrc] = useState("");

    const [searchValue, setSearchValue] = useState("");

    const handleAdText = () => {
        let adObj = [
            { adTitle: "Coca-Cola", adContent: "The Wonder of Us", adImgSrc:"https://naldzgraphics.net/wp-content/uploads/2011/10/coca-cola.ads.jpg" },
            { adTitle: "Budweiser", adContent: "Stand By You", adImgSrc:"https://naldzgraphics.net/wp-content/uploads/2011/10/coca-cola.ads.jpg" },
            { adTitle: "Ancestry", adContent: "Declaration Descendants", adImgSrc:"https://naldzgraphics.net/wp-content/uploads/2011/10/coca-cola.ads.jpg" },
            { adTitle: "Apple Earth", adContent: "Shot on iPhone", adImgSrc:"https://naldzgraphics.net/wp-content/uploads/2011/10/coca-cola.ads.jpg" },
            { adTitle: "Nike", adContent: "What Will They Say About You", adImgSrc:"https://naldzgraphics.net/wp-content/uploads/2011/10/coca-cola.ads.jpg" },
            { adTitle: "Burger King", adContent: "Bullying Jr", adImgSrc:"https://naldzgraphics.net/wp-content/uploads/2011/10/coca-cola.ads.jpg" }
        ];
        let adIndex = Math.floor(Math.random() * 6);
        setAdTitle(adObj[adIndex].adTitle);
        setAdContent(adObj[adIndex].adContent);
        setAdImgSrc(adObj[adIndex].adImgSrc);
    };

    useEffect(() => {
        handleAdText();
    }, [searchValue]);

    return (
        <main className="overflow-auto flex-1">
            <Advertisement adtitle={adTitle} adcontent={adContent} adimgsrc={adImgSrc} />
            <input type="text" className="focus:outline-none px-4 py-2 border border-orange-600 rounded w-full mb-2" value={searchValue} placeholder="Search here..." onChange={(e)=>setSearchValue(e.target.value)}/>
            <UserDetails />
        </main>
    );
};

export default Content;
