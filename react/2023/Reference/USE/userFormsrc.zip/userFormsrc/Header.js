import React from "react";

const Header = () => {
    return (
        <header className="h-14 bg-orange-900 text-white p-3">
            <p className="text-xl text-center">Header</p>
        </header>
    )
}

export default Header