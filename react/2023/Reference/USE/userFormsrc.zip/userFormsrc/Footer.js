import React from "react";

const Footer = () => {
    return (
        <footer className="w-full h-12 bg-slate-900 text-white p-3">
            <p className="text-xl text-center">Footer</p>
        </footer>
    )
}

export default Footer