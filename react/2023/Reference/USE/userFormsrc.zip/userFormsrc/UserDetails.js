import React, { useState } from "react";
import UserForm from "./UserForm";
import UserList from "./UserList";


const UserDetails = () => {

    const [listOfUserObj,setListOfUserObj] =useState([]);


    return (
        <main className="overflow-auto flex-1">
            <div className="flex">
                <div className="w-5/12">
                    <UserForm listOfUserObj={listOfUserObj} setListOfUserObj={setListOfUserObj} />
                </div>
                <div className="w-7/12">
                    <UserList listOfUserObj={listOfUserObj} setListOfUserObj={setListOfUserObj}/>
                </div>
            </div>
        </main>
    )
}

export default UserDetails