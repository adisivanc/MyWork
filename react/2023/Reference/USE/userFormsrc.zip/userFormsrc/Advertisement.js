import React from "react";

const Advertisement = ({adtitle,adcontent,adimgsrc}) => {
    return (
        <main className="overflow-auto flex-1">
            <div className="relative max-h-32 overflow-hidden">
                <img src={adimgsrc} alt="" className="w-full object-cover"/>
                <div className="bg-zinc-900/60 absolute w-full top-0 left-0 h-full text-2xl text-right font-light py-7 px-10 text-white italic">
                    <h4>{adtitle}</h4> 
                    <p>{adcontent}</p>
                </div>
            </div>            
        </main>
    )
}

Advertisement.defaultProps ={
    title:"Coca-Cola",
    content:"The Wonder of Us",
    adimgsrc:"https://tse2.mm.bing.net/th?id=OIP.rivO4IT-ugfBi19HJYPfdgHaDo&pid=Api&P=0&h=180"
}
export default Advertisement