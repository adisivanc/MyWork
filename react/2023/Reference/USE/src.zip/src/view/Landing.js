import React from "react";

const Landing = () => {
    return (
        <>
            Landing
        </>
    )
}

export default Landing;