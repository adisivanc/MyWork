import React from "react";

const Services = () => {
    return (
        <>
            Services
        </>
    )
}

export default Services;