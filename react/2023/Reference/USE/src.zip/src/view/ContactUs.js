import React from "react";

const ContactUs = () => {
    return (
        <>
            Contact Us
        </>
    )
}

export default ContactUs;