import React from "react";

const AboutUs = () => {
    return (
        <>
            AboutUs
        </>
    )
}

export default AboutUs;